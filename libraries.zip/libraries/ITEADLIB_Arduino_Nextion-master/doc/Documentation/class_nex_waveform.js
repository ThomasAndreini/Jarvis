var class_nex_waveform =
[
    [ "NexWaveform", "class_nex_waveform.html#a4f18ca5050823e874d526141c8595514", null ],
    [ "addValue", "class_nex_waveform.html#a5b04ea7397b784947b845e2a03fc77e4", null ]
];