var class_nex_d_s_button =
[
    [ "NexDSButton", "class_nex_d_s_button.html#a226edd2467f2fdf54848f5235b808e2b", null ],
    [ "getValue", "class_nex_d_s_button.html#a63e08f9a79f326c47aa66e1d0f9648c8", null ],
    [ "setValue", "class_nex_d_s_button.html#a2f696207609e0f01aadebb8b3826b0fa", null ]
];